/**
 * Application Name: Tweeten
 * Application URI: http://tweeten.xyz
 * Description: Tweeten is an app that makes TweetDeck look better. Available on Windows, Mac, and Linux.
 * Version: 2.0.0
 * Authors: Mehedi Hassan, Gustave M.
 * Authors URI: http://tweeten.xyz/devs
 * Copyright 2016  Mehedi Hassan  (email : mehedi@wmpoweruser.com)
 * This program is free software; you can not redistribute it and/or modify
 * it without a written permission from the developers.
 *
 * This program is released in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/

// Important: change this at every release for the update checker to work correctly
var build = 28;
var release_channel = "beta";
var build_string = "0.1.160508-2200"

var app = require('app');
var BrowserWindow = require('browser-window');

var Menu = require('menu');
var dialog = require('dialog');
var ipc = require('ipc');

const shell = require('shell');

var storage = require("./js/storage.js");

var settings = storage.get("settings");
if (settings === null) {
    settings = {
        window: {
            width: 1200,
            height: 768,
            maximized: false,
            autohidemenubar: true,
            alwaysontop: false
        },
        theme: "dark",
        column_size: 310,
        sync: true,
        first_run_passed: false,
        card: false,
        spell: false,
        icon: false,
        profilepic: true,
        convoindicator: false,
        tray: false,
        adtweetaction: false,
        showsep: false
    }
}

// Prevents application running in the background after everything is closed
app.on('window-all-closed', app.quit);

// Sets Windows 8 App ID for toast notifications
app.setAppUserModelId('Tweeten');

// General request function, right now, can only returns the current settings values
ipc.on('invokeAction', function (event, data) {
    if (data == 'get_settings') {
        event.sender.send('actionReply', settings);
    }
});


// When app is ready
app.on('ready', () => {

    // Launch about function, will display version number and etc...
    ipc.on('launch_about', function (event) {
         dialog.showMessageBox({ type: "info", title: "Tweeten", detail: "Version " + build_string + "\nUpdate channel: " + release_channel, message: "About Tweeten",
      buttons: ["OK"] });
    });

    // Launch settings option
    ipc.on('launch_settings', function (event) {
        var prefsWindow = new BrowserWindow({
            width: 550,
            height: 565,
            "autoHideMenuBar": true,
            resizable: true,
            "always-on-top": false,
            maximizable: false,
            minimizable: false,
            fullscreenable: false
        })
        var session2 = prefsWindow.webContents.session;
        session2.clearCache(function () {});
        prefsWindow.focus();
        prefsWindow.loadURL('file://' + __dirname + '/pages/settings.html');
    });

    // Create the main window
    var mainWindow = new BrowserWindow({
        x: settings.window.x,
        y: settings.window.y,
        width: settings.window.width,
        height: settings.window.height,
        'auto-hide-menu-bar': settings.window.autohidemenubar,
        "webPreferences":  {
            "webSecurity": false,
            "allowRunningInsecureContent": true,
            "allowDisplayingInsecureContent": true
        }
    });

    // Clear previous cache to avoid cached variables issues
    var session = mainWindow.webContents.session
    session.clearCache(() => {});

    // Load previously stored alwaysontop setting
    mainWindow.setAlwaysOnTop(settings.window.alwaysontop);

    // Save window state when closing
    mainWindow.on('close', () => {
        var bounds = mainWindow.getBounds();
        if (mainWindow.isMaximized()) {
            settings.window.maximized = mainWindow.isMaximized();
            settings.window.autohidemenubar = mainWindow.isMenuBarAutoHide();
            settings.window.alwaysontop = mainWindow.isAlwaysOnTop();
            storage.set("settings", settings);
        } else {
            settings.window.x = bounds.x;
            settings.window.y = bounds.y;
            settings.window.width = bounds.width;
            settings.window.height = bounds.height;
            settings.window.maximized = mainWindow.isMaximized();
            settings.window.autohidemenubar = mainWindow.isMenuBarAutoHide();
            settings.window.alwaysontop = mainWindow.isAlwaysOnTop();
            storage.set("settings", settings);
        }
    });

    // Restore previous maximized state
    if (settings.window.maximized) {
        mainWindow.maximize();
    }

    // Set Minimum Window Size.
    mainWindow.setMinimumSize(378, 350);

    // ran when the first run was completed by the user, this essentially sets a flag to prevent the first run wizard to run again
    ipc.on('first_run_passed', function () {
        settings.first_run_passed = true;
        storage.set("settings", settings);
    });


    // Run first run
    ipc.on('ask_first_run', function (event) {
        ipc.on('first_run_data', function (event, data) {
            if (settings.first_run_passed == false) {
                var command = "show_first_run(['"+data[0]+"','"+data[1]+"']);"
                mainWindow.webContents.executeJavaScript(command);
            }
        });
    });

    // Function ran when we detect Tweetdeck current theme, to sync it with tweeten at first run
    ipc.on('sync_theme', function (event, data) {
        settings.theme = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    // Function ran when the user triggered a manual theme change, will sets TD default theme too
    ipc.on('change_theme', function (event, data) {
        settings.theme = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"', true]);"
        mainWindow.webContents.executeJavaScript(command);
    });

    // Function ran when the user changed the column size
    ipc.on('change_column_size', function (event, data) {
        settings.column_size = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    ipc.on('change_card', function (event, data) {
        settings.card = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    ipc.on('change_icon', function (event, data) {
        settings.icon = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    ipc.on('change_profilepic', function (event, data) {
        settings.profilepic = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    ipc.on('change_spell', function (event, data) {
        settings.spell = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    ipc.on('change_convoindicator', function (event, data) {
        settings.convoindicator = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    ipc.on('change_tray', function (event, data) {
        settings.tray= data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });


    ipc.on('change_adtweetaction', function (event, data) {
        settings.adtweetaction= data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });


    ipc.on('change_showsep', function (event, data) {
        settings.showsep = data;
        storage.set("settings", settings);
        var command = "switch_theme(['"+settings.theme+"','"+settings.column_size+"']);"
        mainWindow.webContents.executeJavaScript(command);
    });

    mainWindow.on('minimize', function(event){
      if (settings.tray == true) {
        var Tray = require('tray');
        var path = require('path');
        var iconPath = path.join(__dirname, '/assets/tray.png');
        var appIcon = null;
        mainWindow.hide();
        appIcon = new Tray(iconPath);
        var contextMenu = Menu.buildFromTemplate([
          {
              label: 'Open Tweeten',
              click: function () {
                mainWindow.show();
                appIcon.destroy();
              }
          },
          {
              label: 'Settings',
              click: function () {
                var prefsWindow = new BrowserWindow({
                  width: 535,
                  height: 520,
                  "autoHideMenuBar": true,
                  resizable: false,
                  "always-on-top": false,
                  maximizable: false,
                  minimizable: false,
                  fullscreenable: false
                })
                var session2 = prefsWindow.webContents.session;
                session2.clearCache(function () {});
                prefsWindow.focus();
                prefsWindow.loadURL('file://' + __dirname + '/pages/settings.html');
              }
          },
          {
              label: 'Exit',
              click: function () {
                  appIcon.destroy();
                  app.quit();
              }
          }
        ]);
        appIcon.setToolTip('Tweeten');
        appIcon.setContextMenu(contextMenu);
        appIcon.on('click', function() {
          mainWindow.show();
          appIcon.destroy();
        });
      }

    });

    ipc.on('open_card', function (event, data) {
        var command = "preview_card('"+data+"');"
        mainWindow.webContents.executeJavaScript(command);
    });

    // Loads Main Page
    mainWindow.loadURL('file://' + __dirname + '/pages/index.html');

    // Focuses Window
    mainWindow.focus();

    // Open dev tools
    //mainWindow.openDevTools();


    // Check for updates function
    ipc.on('ask_updates', function (event_, resp_) {

        var onlineStatusWindow;
        onlineStatusWindow = new BrowserWindow({ width: 0, height: 0, show: false });
        var session3 = onlineStatusWindow.webContents.session
        session3.clearCache(function () {});
        onlineStatusWindow.loadURL('file://' + __dirname + '/pages/update_checker.html');

        ipc.on('update_checker_xml', function (event, resp) {
            var remote_build = parseInt(resp[release_channel].build);
            if (remote_build > build) {
                event_.sender.send('show_update_dialog', resp[release_channel]);
                ipc.removeAllListeners('update_yes');
                ipc.once('update_yes', function () {
                    var url = resp[release_channel].download_url
                    switch (process.platform) {
                        case 'darwin':
                            url = url + '/tweeten-darwin';
                            break;
                        case 'linux':
                            url = url + '/tweeten-linux';
                            break;
                        case 'win32':
                            url = url + '/tweeten-win32';
                            break;
                    }
                    switch (process.arch) {
                        case 'arm':
                            url = url + '-arm';
                            break;
                        case 'ia32':
                            url = url + '-ia32';
                            break;
                        case 'x64':
                            url = url + '-x64';
                            break;
                    }
                    switch (process.platform) {
                        case 'darwin':
                            url = url + '.zip';
                            break;
                        case 'linux':
                            url = url + '.zip';
                            break;
                        case 'win32':
                            url = url + '.exe';
                            break;
                    }
                    shell.openExternal(url);
                    mainWindow.close();
                });
            }
        });
    });
});
