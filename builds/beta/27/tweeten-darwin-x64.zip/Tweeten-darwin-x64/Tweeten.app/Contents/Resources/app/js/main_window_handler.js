/**
 * Application Name: Tweeten
 * Application URI: http://tweeten.xyz
 * Description: Tweeten is an app that makes TweetDeck look better. Available on Windows, Mac, and Linux.
 * Version: 0.1
 * Authors: Mehedi Hassan, Gustave M.
 * Authors URI: http://tweeten.xyz/devs
 * Copyright 2016  Mehedi Hassan  (email : mehedi@wmoweruser)
 * This program is free software; you can not redistribute it and/or modify
 * it without a written permission from the developers.
 *
 * This program is released in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*/
(function () {
    const electron = require('electron');
    const remote = electron.remote;
    var MenuItem = remote.require('menu-item');
    var ipc = require('ipc');
    var Menu = remote.require('menu');
    var window = remote.getCurrentWindow();


	document.ondragover = document.ondrop = function (e) {
        e.preventDefault();
        return false;
    };

    if (process.platform == 'darwin') {
        var template = [
            {
                label: 'Tweeten',
                submenu: [
                    {
                        label: 'Settings',
                        click: function () {
                            ipc.send('launch_settings');
                        }
                    },
                    {
                        label: 'Changelog',
                        click: function () {
                            show_changelog();
                        }
                    },
                    {
                        label: 'Check for updates',
                        click: () => {
                            check_for_updates();
                        }
                    },
                    {
                        label: 'About ' + name,
                        click: function () {
                            ipc.send('launch_about');
                        }
                    },
                    {
                        type: 'separator'
                    },
                    {
                        label: 'Services',
                        role: 'services',
                        submenu: []
                    },
                    {
                        type: 'separator'
                    },
                    {
                        label: 'Hide ' + name,
                        accelerator: 'Command+H',
                        role: 'hide'
                    },
                    {
                        label: 'Hide Others',
                        accelerator: 'Command+Shift+H',
                        role: 'hideothers'
                    },
                    {
                        label: 'Show All',
                        role: 'unhide'
                    },
                    {
                        type: 'separator'
                    },
                    {
                        label: 'Quit',
                        accelerator: 'Command+Q',
                        click: function (item, focusedWindow) {
                            if (focusedWindow)
                                focusedWindow.close();
                        }
                    },
                ]
            },
            {
                label: 'Edit',
                submenu: [
                    {
                        label: 'Cut',
                        accelerator: 'CmdOrCtrl+X',
                        role: 'cut'
                    },
                    {
                        label: 'Copy',
                        accelerator: 'CmdOrCtrl+C',
                        role: 'copy'
                    },
                    {
                        label: 'Paste',
                        accelerator: 'CmdOrCtrl+V',
                        role: 'paste'
                    },
                    {
                        label: 'Select all',
                        accelerator: 'CmdOrCtrl+A',
                        role: 'selectall'
                    }
                ]
            },
            {
                label: 'View',
                submenu: [
                    {
                        label: 'Reload',
                        accelerator: 'CmdOrCtrl+R',
                        click: function (item, focusedWindow) {
                            if (focusedWindow) {
                                webview.reload();
                            }
                        }
                    },
                    {
                        label: 'Toggle menu bar auto hide',
                        accelerator: 'Alt',
                        click: function (item, focusedWindow) {
                            if (focusedWindow) {
                                focusedWindow.setAutoHideMenuBar(!focusedWindow.isMenuBarAutoHide());
                            }
                        }
                    },
                    {
                        label: 'Toggle full screen',
                        accelerator: (function () {
                            if (process.platform == 'darwin')
                                return 'Ctrl+Command+F';
                            else
                                return 'F11';
                        })(),
                        click: function (item, focusedWindow) {
                            if (focusedWindow)
                                focusedWindow.setFullScreen(!focusedWindow.isFullScreen());
                        }
                    },
                    {
                        label: 'Toggle always on top',
                        click: function (item, focusedWindow) {
                            if (focusedWindow)
                                focusedWindow.setAlwaysOnTop(!focusedWindow.isAlwaysOnTop());
                        }
                    }
                ]
            },
            {
                label: 'Window',
                role: 'window',
                submenu: [
                    {
                        label: 'Minimize',
                        accelerator: 'CmdOrCtrl+M',
                        role: 'minimize'
                    }, {
                        label: 'Close',
                        accelerator: 'CmdOrCtrl+W',
                        role: 'close'
                    }, ]
            },
            {
                label: 'Help',
                role: 'help',
                submenu: [
                        {
                        label: 'Provide feedback',
                        click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
                    }, {
                        label: 'Bug report',
                        click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
                    }, {
                        label: 'Follow us',
                        click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
                    }]
            }
        ];
        Menu.setApplicationMenu(Menu.buildFromTemplate(template));
    } else {
        var template = [
            {
                label: 'Tweeten',
                submenu: [
                    {
                        label: 'Settings',
                        click: function () {
                            ipc.send('launch_settings');
                        }
                    },
                    {
                        label: 'Check for updates',
                        click: () => {
                            check_for_updates();
                        }
                    },
                    {
                        label: 'Changelog',
                        click: function () {
                            show_changelog();
                        }
                    },
                    {
                        label: 'About',
                        click: function () {
                            ipc.send('launch_about');
                        }
                    }
                ]
            },
            {
                label: 'Edit',
                submenu: [
                    {
                        label: 'Cut',
                        accelerator: 'CmdOrCtrl+X',
                        role: 'cut'
                    },
                    {
                        label: 'Copy',
                        accelerator: 'CmdOrCtrl+C',
                        role: 'copy'
                    },
                    {
                        label: 'Paste',
                        accelerator: 'CmdOrCtrl+V',
                        role: 'paste'
                    },
                    {
                        label: 'Select all',
                        accelerator: 'CmdOrCtrl+A',
                        role: 'selectall'
                    }
                ]
            },
            {
                label: 'View',
                submenu: [
                    {
                        label: 'Reload',
                        accelerator: 'CmdOrCtrl+R',
                        click: function (item, focusedWindow) {
                            if (focusedWindow) {
                                webview.reload();
                            }
                        }
                    },
                    {
                        label: 'Toggle menu bar auto hide',
                        accelerator: 'Alt',
                        click: function (item, focusedWindow) {
                            if (focusedWindow) {
                                focusedWindow.setAutoHideMenuBar(!focusedWindow.isMenuBarAutoHide());
                            }
                        }
                    },
                    {
                        label: 'Toggle full screen',
                        accelerator: (function () {
                            if (process.platform == 'darwin')
                                return 'Ctrl+Command+F';
                            else
                                return 'F11';
                        })(),
                        click: function (item, focusedWindow) {
                            if (focusedWindow)
                                focusedWindow.setFullScreen(!focusedWindow.isFullScreen());
                        }
                    },
                    {
                        label: 'Toggle always on top',
                        click: function (item, focusedWindow) {
                            if (focusedWindow)
                                focusedWindow.setAlwaysOnTop(!focusedWindow.isAlwaysOnTop());
                        }
                    }
                ]
            },
            {
                label: 'Window',
                role: 'window',
                submenu: [
                    {
                        label: 'Minimize',
                        accelerator: 'CmdOrCtrl+M',
                        role: 'minimize'
                    }, {
                        label: 'Close',
                        accelerator: 'CmdOrCtrl+W',
                        role: 'close'
                    },
                ]
            },
            {
                label: 'Help',
                role: 'help',
                submenu: [
                    {
                        label: 'Provide feedback',
                        click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
                    },
                    {
                        label: 'Bug report',
                        click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
                    },
                    {
                        label: 'Follow us',
                        click: function () { require('shell').openExternal('http://twitter.com/tweetenapp') }
                    }
                ]
            }
        ];
        Menu.setApplicationMenu(Menu.buildFromTemplate(template));
    }

    var webview = document.getElementById('content');

    var menu = new Menu();
    menu.append(new MenuItem({ label: 'Cut', accelerator: 'CmdOrCtrl+X', role: 'cut' }));
    menu.append(new MenuItem({ label: 'Copy', accelerator: 'CmdOrCtrl+C', role: 'copy' }));
    menu.append(new MenuItem({ label: 'Paste', accelerator: 'CmdOrCtrl+V', role: 'paste' }));
    menu.append(new MenuItem({ label: 'Select All', accelerator: 'CmdOrCtrl+A', role: 'selectall' }));
    menu.append(new MenuItem({ type: 'separator' }));
    menu.append(new MenuItem({
        label: 'Toggle full screen',
        accelerator: (function () {
            if (process.platform == 'darwin')
                return 'Ctrl+Command+F';
            else
                return 'F11';
        })(),
        click: function (item, focusedWindow) {
            if (focusedWindow)
                focusedWindow.setFullScreen(!focusedWindow.isFullScreen());
        }
    }));
    menu.append(new MenuItem({
        label: 'Toggle always on top',
        click: function (item, focusedWindow) {
            if (focusedWindow)
                focusedWindow.setAlwaysOnTop(!focusedWindow.isAlwaysOnTop());
        }
    }));
    menu.append(new MenuItem({
        label: 'Settings',
        click: function () {
            ipc.send('launch_settings');
        }
    }));
    menu.append(new MenuItem({
        label: 'Check for updates',
        click: () => {
            check_for_updates();
        }
    }));
    menu.append(new MenuItem({
        label: 'Changelog',
        click: function () {
            show_changelog();
        }
    }));
    menu.append(new MenuItem({
        label: 'Window',
        role: 'window',
        submenu: [
            {
                label: 'Minimize',
                accelerator: 'CmdOrCtrl+M',
                role: 'minimize'
            }, {
                label: 'Close',
                accelerator: 'CmdOrCtrl+W',
                role: 'close'
            },
        ]
    }));
    menu.append(new MenuItem({ label: 'Help', submenu: [
        {
            label: 'Reload',
            accelerator: 'CmdOrCtrl+R',
            click: function (item, focusedWindow) {
                if (focusedWindow) {
                    webview.reload();
                }
            }
        },
        {
            type: 'separator'
        },
        {
            label: 'Provide feedback',
            click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
        },
        {
            label: 'Bug report',
            click: function () { require('shell').openExternal('https://github.com/MehediH/Tweeten/issues') }
        },
        {
            label: 'Follow us',
            click: function () { require('shell').openExternal('http://twitter.com/tweetenapp') }
        },
        {
            label: 'About',
            click: function () {
                ipc.send('launch_about');
            }
        }
    ]}));

    webview.addEventListener('contextmenu', function (e) {
        e.preventDefault();
        menu.popup(remote.getCurrentWindow());
    }, false);

    webview.addEventListener("dom-ready", function () {
        webview.focus();
    });

    window.on('focus', () => {
        webview.focus();
    });

    window.on('blur', () => {
        webview.focus();
    });

})();
