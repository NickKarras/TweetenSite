var ipc = require('ipc');

function check_for_updates() {

    var update_later = document.getElementById('update_later');
    var update_download = document.getElementById('update_download');
    var darken = document.getElementById('darken');
    var update_dialog = document.getElementById('update_dialog');
    var update_title = document.getElementById('update_title');
    var update_description = document.getElementById('update_description');

    ipc.send('ask_updates');
    ipc.on('show_update_dialog', function (response) {
        darken.style.display = 'inherit';
        update_dialog.style.display = 'inherit';
        update_dialog.className = 'show_fadein';

        update_title.innerHTML = "<p>" + 'A new software update is now available: ' + response.title + "</p>";
        update_description.innerHTML = response.description + '<p>Released on: ' + response.publish_date + "</p>";
    });

    update_later.addEventListener('click', () => {
        darken.style.display = 'none';
        update_dialog.style.display = 'none';
        update_dialog.className = '';
    });
    
    darken.addEventListener('click', () => {
        darken.style.display = 'none';
        update_dialog.style.display = 'none';
        update_dialog.className = '';
    });

    update_download.addEventListener('click', () => {
        darken.style.display = 'none';
        update_dialog.style.display = 'none';
        update_dialog.className = '';

        ipc.send('update_yes');
    });
}

check_for_updates();
ipc.on('check_for_updates', function () {
    check_for_updates();
});