function show_changelog() {
    var changelog_close = document.getElementById('changelog_close');
    var darken3 = document.getElementById('darken3');
    var changelog_dialog = document.getElementById('changelog_dialog');

    darken3.style.display = 'inherit';
    changelog_dialog.style.display = 'inherit';
    changelog_dialog.className = 'show_fadein';

    changelog_close.addEventListener('click', () => {
        darken3.style.display = 'none';
        changelog_dialog.style.display = 'none';
        changelog_dialog.className = '';
    });
    
    darken3.addEventListener('click', () => {
        darken3.style.display = 'none';
        changelog_dialog.style.display = 'none';
        changelog_dialog.className = '';
    });
}