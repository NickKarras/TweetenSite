function add_account() {
    var add_account = document.getElementById('add_account');
    var add_account_webview = document.getElementById('add_account_webview');
    var darken4 = document.getElementById('darken4');
    var webview = document.getElementById('content');
    
    darken4.removeEventListener('click');
    add_account_webview.removeEventListener('did-finish-load');
    
    darken4.style.display = 'inherit';
    add_account.style.display = 'inherit';
    add_account.className = 'show_fadein';
    
    darken4.addEventListener('click', () => {
        darken4.style.display = 'none';
        add_account.style.display = 'none';
        add_account_webview.loadURL("https://tweetdeck.twitter.com/oauth/authorize/twitter?force_login=true");
    });
    
    add_account_webview.addEventListener("did-finish-load", function () {
        if(add_account_webview.getURL().indexOf('https://tweetdeck.twitter.com/oauth/success/twitter') > -1) {
            var tokens = add_account_webview.getURL().split('?')[1]
            var oauth_token = tokens.split('&')[0].split('=')[1];
            var oauth_token_secret = tokens.split('&')[1].split('=')[1];
            webview.executeJavaScript('TD.storage.accountController.addAccountFromOAuthKeys("'+oauth_token+'", "'+oauth_token_secret+'")');
            darken4.style.display = 'none';
            add_account.style.display = 'none';
            add_account_webview.loadURL("https://tweetdeck.twitter.com/oauth/authorize/twitter?force_login=true");
        }
    });
    
}