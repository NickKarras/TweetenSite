var ipc = require('ipc');
var currentcolumnsize;
var currenttheme;

if (process.platform != 'win32') {
     document.getElementById("traylabel").style.display = 'none';
}

ipc.send('invokeAction', 'get_settings');
ipc.on('actionReply', function (response) {
    document.getElementById(response.theme).checked = true;
    document.getElementById("columnsize").value = response.column_size;
    currentcolumnsize = response.column_size;
    document.getElementById("card").checked = response.card;
    document.getElementById("icon").checked = response.icon;
    document.getElementById("profilepic").checked = response.profilepic;
    document.getElementById("spell").checked = response.spell;
    document.getElementById("convoindicator").checked = response.convoindicator;
    document.getElementById("tray").checked = response.tray;
    document.getElementById("adtweetaction").checked = response.adtweetaction;
    document.getElementById("showsep").checked = response.showsep;
});

var apply = document.getElementById('Apply');

var radios_theme = document.getElementsByName('theme');
for (var i = 0, length = radios_theme.length; i < length; i++) {
    if (radios_theme[i].checked) {
        currenttheme = radios_theme[i].value;
    }
}

apply.addEventListener('click', function () {
    var radios_theme = document.getElementsByName('theme');
    for (var i = 0, length = radios_theme.length; i < length; i++) {
        if (radios_theme[i].checked) {
            if (radios_theme[i].value != currenttheme) {
                ipc.send('change_theme', radios_theme[i].value);
                currenttheme = radios_theme[i].value;
            }
        }
    }

    ipc.send("change_card", document.getElementById('card').checked);
    ipc.send("change_icon", document.getElementById('icon').checked);
    ipc.send("change_profilepic", document.getElementById('profilepic').checked);
    ipc.send("change_spell", document.getElementById('spell').checked);
    ipc.send("change_convoindicator", document.getElementById("convoindicator").checked);
    ipc.send("change_tray", document.getElementById("tray").checked);
    ipc.send("change_adtweetaction", document.getElementById("adtweetaction").checked);
    ipc.send("change_showsep", document.getElementById("showsep").checked);

    if (currentcolumnsize != document.getElementById("columnsize").value) {
        ipc.send('change_column_size', document.getElementById("columnsize").value);
        currentcolumnsize = document.getElementById("columnsize").value;
    }

});

document.getElementById("columnsize").onchange = function () {
    if (currentcolumnsize != document.getElementById("columnsize").value) {
        ipc.send('change_column_size', document.getElementById("columnsize").value);
        currentcolumnsize = document.getElementById("columnsize").value;
    }
}
