var ipc = require('ipc');

ipc.send('ask_first_run');
function show_first_run(response) {

    var welcome = document.getElementById('welcome');
    var username = document.getElementById('username');
    var userpic = document.getElementById('userpic');
    var next_screen = document.getElementById('next-screen');
    var darken2 = document.getElementById('darken2');
    var welcome_settings = document.getElementById('welcome_settings');

    darken2.style.display = 'inherit';
    welcome.style.display = 'inherit';
    welcome.className = 'show_fadein';

    darken2.addEventListener('click', () => {
        darken2.style.display = 'none';
        welcome_settings.style.display = 'none';
        welcome.style.display = 'none';
        ipc.send('first_run_passed');
    });

    username.innerHTML = response[0];
    userpic.src = response[1];

    next_screen.addEventListener('click', () => {
        welcome.style.display = 'none';
        welcome_settings.style.display = 'inherit';


        var currentcolumnsize;
        var currenttheme;

        ipc.send('invokeAction', 'get_settings');
        ipc.on('actionReply', function (response) {
            document.getElementById(response.theme).checked = true;
            document.getElementById("columnsize").value = response.column_size;
            currentcolumnsize = response.column_size;
        });

        var apply = document.getElementById('Apply');

        var radios_theme = document.getElementsByName('theme');
        for (var i = 0, length = radios_theme.length; i < length; i++) {
            if (radios_theme[i].checked) {
                currenttheme = radios_theme[i].value;
            }
        }

        apply.addEventListener('click', function () {
            var radios_theme = document.getElementsByName('theme');
            for (var i = 0, length = radios_theme.length; i < length; i++) {
                if (radios_theme[i].checked) {
                    if (radios_theme[i].value != currenttheme) {
                        ipc.send('change_theme', radios_theme[i].value);
                        currenttheme = radios_theme[i].value;
                    }
                }
            }
            if (currentcolumnsize != document.getElementById("columnsize").value) {
                ipc.send('change_column_size', document.getElementById("columnsize").value);
                currentcolumnsize = document.getElementById("columnsize").value;
            }
            darken2.style.display = 'none';
            welcome_settings.style.display = 'none';
            ipc.send('first_run_passed');
        });

        document.getElementById("columnsize").onchange = function () {
            if (currentcolumnsize != document.getElementById("columnsize").value) {
                ipc.send('change_column_size', document.getElementById("columnsize").value);
                currentcolumnsize = document.getElementById("columnsize").value;
            }
        }
    });
}
