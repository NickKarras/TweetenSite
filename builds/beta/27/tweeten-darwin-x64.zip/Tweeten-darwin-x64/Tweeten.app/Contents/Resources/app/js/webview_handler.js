var ipc = require('ipc');
const electron = require('electron');
const shell = electron.shell;

var webview = document.getElementById('content');
var login = document.getElementById('login');
var logoff = document.getElementById('logoff');

function switch_theme(response) {
	if (webview.style.display != "none") {
		var theme = response[0];
		var column_size = response[1];
		var cssfile;
		var css;
		var client = new XMLHttpRequest();
		var client2 = new XMLHttpRequest();
		var client3 = new XMLHttpRequest();
		var client4 = new XMLHttpRequest();
		var detective = new Detector();

		if (response[2]) {
			webview.executeJavaScript('TD.settings.setTheme("' + theme + '");');
		}

		switch (theme) {
			case 'dark': {
				cssfile = '../styles/dark.css';
				break;
			}
			case 'light': {
				cssfile = '../styles/light.css';
				break;
			}
			default: {
				cssfile = '../styles/dark.css';
			}
		}

		client4.open('GET', '../styles/common.css');
		client4.onreadystatechange = function () {
			client3.open('GET', '../styles/column_size.css');
			client3.onreadystatechange = function () {
				client2.open('GET', '../styles/font.css');
				client2.onreadystatechange = function () {
					client.open('GET', cssfile);
					client.onreadystatechange = function () {
						css = client4.responseText + client3.responseText.replace('INSERT_COLUMN_WIDTH', column_size);
						if (detective.detect('Segoe MDL2 Assets')) {
							css = css + client2.responseText;
						}
						css = css + client.responseText;
						webview.insertCSS(css);
					}
					client.send();
				}
				client2.send();
			}
			client3.send();
		}
		client4.send();
	}
}

ipc.send('invokeAction', 'get_settings');
ipc.on('actionReply', function (response) {
    webview.addEventListener("load-commit", function () {
        switch_theme([response.theme, response.column_size]);
    });
});

webview.addEventListener("dom-ready", function () {
  //webview.openDevTools();
});

webview.addEventListener('new-window', function (e) {
    e.preventDefault();
    if (e.url.indexOf('https://tweetdeck.twitter.com/oauth/authorize/twitter') > -1) {
        add_account();
    } else {
        shell.openExternal(e.url);
    }
});

webview.addEventListener('will-navigate', function (e) {
	if (e.url.indexOf('https://twitter.com/login?hide_message=true&redirect_after_login=https%3A%2F%2Ftweetdeck.twitter.com%2F%3Fvia_twitter_login%3Dtrue') > -1) {
		webview.style.display = "none";
		login.style.display = "inherit";
		login.loadUrl("https://twitter.com/login?hide_message=true&redirect_after_login=https%3A%2F%2Ftweetdeck.twitter.com%2F%3Fvia_twitter_login%3Dtrue");
	} else if (e.url.indexOf('https://twitter.com/logout?redirect_after_logout=https%3A%2F%2Ftweetdeck.twitter.com%2F') > -1) {
		webview.style.display = "none";
		logoff.style.display = "inherit";
		logoff.loadUrl("https://twitter.com/logout?redirect_after_logout=https%3A%2F%2Ftweetdeck.twitter.com%2F");
	}
});

login.addEventListener('page-title-updated', function (e) {
	if (e.title === "TweetDeck") {
		webview.style.display = "inherit";
		login.style.display = "none";
		webview.loadURL('https://tweetdeck.twitter.com/?via_twitter_login=true')
	}
});

logoff.addEventListener('page-title-updated', function (e) {
	if (e.title === "TweetDeck") {
		webview.style.display = "inherit";
		logoff.style.display = "none";
		webview.loadURL('https://tweetdeck.twitter.com/')
	}

});
