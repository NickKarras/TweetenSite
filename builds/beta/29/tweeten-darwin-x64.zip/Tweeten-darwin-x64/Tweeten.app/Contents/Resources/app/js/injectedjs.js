var cardsupport = false;

function when(conditionFunc, execFunc, interval) {
    if (conditionFunc()) {
        execFunc();
    } else {
        setTimeout(function() {
            when(conditionFunc, execFunc, interval);
        }, interval);
    }
}

var ipc = require('ipc');

function sendNeededFirstRunData() {
    ipc.send('first_run_data', new Array(document.getElementsByClassName('nav-user-info')[0].getElementsByClassName('fullname')[0].innerHTML.substring(1).substring(-1), document.getElementsByClassName('nav-user-info')[0].getElementsByClassName('tweet-avatar')[0].src.replace('_normal', '').replace('_bigger', '')));
}

function syncTDSettings() {
    ipc.send('invokeAction', 'get_settings');
    ipc.on('actionReply', function(response) {
        if (response.theme != TD.settings.getTheme()) {
            ipc.send('sync_theme', TD.settings.getTheme());
        }
    });
}

function UrlExists(url) {
    var http = new XMLHttpRequest();
    http.open('HEAD', url, false);
    http.send();
    return http.status != 404;
}

function makeHttpObject() {
    try {
        return new XMLHttpRequest();
    } catch (error) {}
    try {
        return new ActiveXObject("Msxml2.XMLHTTP");
    } catch (error) {}
    try {
        return new ActiveXObject("Microsoft.XMLHTTP");
    } catch (error) {}

    throw new Error("Could not create HTTP request object.");
}

function TwitterCardsSupport() {
    var tweets = document.getElementsByClassName('js-tweet-detail');
    for (var i = 0; i < tweets.length; i++) {
        var tweet = tweets[i].getElementsByClassName('stream-item')[0];
        var id = tweet.getAttribute("data-key").toString();
        if (tweet.getAttribute("data-key").indexOf("_") != -1) {
            id = tweet.getAttribute("data-key").split("_")[tweet.getAttribute("data-key").split("_").length - 1].toString()
        }
        if (tweets[i].getElementsByClassName('card')[0] == null) {
            var div = document.createElement('a');
            div.className = "card";
            //div.style.pointerEvents = "none";
            if (UrlExists("https://twitter.com/i/cards/tfw/v1/" + id)) {
                var request = makeHttpObject();
                request.open("GET", ("https://twitter.com/i/cards/tfw/v1/" + id), true);
                request.send(null);
                request.onreadystatechange = function() {
                    if (request.readyState == 4) {
                        var add_link = false;
                        var link;
                        for (var e = 0; e < request.responseText.split(',').length; e++) {
                            if (request.responseText.split(',')[e].indexOf('card_uri') > -1) {
                                link = ("https:" + request.responseText.split(',')[e].split(':')[2].replace('"', ""));
                                if (link != "https://twitter.com") {
                                    add_link = true;
                                }
                                break;
                            }
                        }
                        if (add_link) {
                            div.setAttribute('target', '_blank');
                            div.setAttribute('href', link);
                            div.setAttribute('data-full-url', link);
                            div.className = "card url-ext";
                            div.setAttribute('rel', 'url');
                        }
                        div.style.display = "block";
                        var container = document.createElement('div');
                        container.style.pointerEvents = 'none';
                        container.innerHTML = request.responseText;
                        div.appendChild(container);
                    }
                };
                tweets[i].className = (tweets[i].className + " has-twitter-card");
            }
            tweets[i].getElementsByClassName('js-cards-container')[0].appendChild(div);
        }
    }
}

// Allows the user to click on an image to view its full resolution in the browser
function replaceImagesLinks() {
    var images = document.getElementsByClassName('js-media-image-link');
    for (var i = 0; i < images.length; i++) {
        var img = images[i];
        if (img.getAttribute("data-media-entity-id") == "") {
            if (img.getElementsByTagName('img')[0] != null) {
                var newUrl = (img.getElementsByTagName('img')[0].src.split(':')[0] + ':' + img.getElementsByTagName('img')[0].src.split(':')[1] + ':orig');
                if (img.href != newUrl) {
                    img.href = newUrl
                }
            }
        }
    }
}

document.addEventListener('load', replaceImagesLinks, false)

//Loads JQuery and Adds Custom Shortcuts
function load_jqery_and_shortcuts() {
    window.onkeydown = function(event) {
        if (event.keyCode === 27) {
            $(".js-column-back").click();
        }
    };
}

function setUpSpellChecking() {
    ipc.on('actionReply', function(response) {
        if (response.spell) {
            var webFrame = require('electron').webFrame;
            var Typo = require("typo-js");
            var languagecode = (TD.languages.getSystemLanguageCode())
            var dictionary = new Typo(languagecode);
            webFrame.setSpellCheckProvider(languagecode, false, {
                spellCheck: function(text) {
                    return dictionary.check(text);
                }
            });
        }
    });
}

function checksettings() {
    ipc.on('actionReply', function(response) {
        setCardSupport(response.card);
        setIconSupport(response.icon);
        setConvoSupport(response.convoindicator);
        setProfilePicSupport(response.profilepic);
        setadtweetaction(response.adtweetaction);
        setshowsep(response.showsep);
    });
}

function setCardSupport(enabled) {
    cardsupport = enabled;
}

function setIconSupport(enabled) {
    var root = document.getElementsByTagName('html')[0]
    if (enabled) {
        root.className.replace(' classic-tweeten-icons', '');
    } else {
        root.className += ' classic-tweeten-icons';
    }
}

function setshowsep(enabled) {
    var root = document.getElementsByTagName('html')[0]
    if (enabled) {
        root.className += ' tweeten-show-sep';

    } else {
        root.className.replace(' tweeten-show-sep', '');

    }
}

function setadtweetaction(enabled) {
    var root = document.getElementsByTagName('html')[0]
    if (enabled) {
        root.className += ' tweeten-show-tweet-action ';
    } else {
        root.className.replace(' tweeten-show-tweet-action', '');
    }
}


function setConvoSupport(enabled) {
    var root = document.getElementsByTagName('html')[0]
    if (enabled) {
        root.className += ' tweeten-convo-indicates';
    } else {
        root.className.replace(' tweeten-convo-indicates', '');
    }
}

function setProfilePicSupport(enabled) {
    var root = document.getElementsByTagName('html')[0]
    if (enabled) {
        root.className.replace(' tweeten-squared-images', '');
    } else {
        root.className += ' tweeten-squared-images';
    }
}

// Executed when Tweetdeck is fully loaded
function loaded() {
    setUpSpellChecking();
    syncTDSettings();
    sendNeededFirstRunData();
    setInterval(function() {
        replaceImagesLinks();
    }, 500);
    checksettings();
    load_jqery_and_shortcuts();
    setInterval(function() {
        if (cardsupport) {
            TwitterCardsSupport();
        }
    }, 500);
}

// Wait until Tweetdeck is fully loaded and execute loaded()
document.addEventListener('DOMContentLoaded', () => {
    when(() => {
        if (document.getElementsByClassName('nav-user-info')[0] == null) {
            return false
        }
        return true
    }, () => {
        loaded();
    }, 1000)
});
